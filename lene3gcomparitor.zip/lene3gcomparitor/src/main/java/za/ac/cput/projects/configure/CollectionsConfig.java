package za.ac.cput.projects.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;

@Configuration
public class CollectionsConfig
{

    @Override


}
