package za.ac.cput.projects.configure.services;

public interface sevice
{

}
