package za.ac.cput.projects;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import za.ac.cput.projects.configure.CollectionsConfig;

public class CollectionTest
{

    private CollectionsConfig collect;

    @BeforeMethod
    public void setUp() throws Exception
    {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        collect = (CollectionsConfig) ctx.getBean("coll");

    }

    @AfterMethod
    public void tearDown() throws Exception
    {

    }
}
